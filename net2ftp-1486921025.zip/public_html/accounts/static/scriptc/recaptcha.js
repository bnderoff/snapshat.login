var recaptchaSolved = function() {
    var submits = $(":submit");
    for (var i = 0; i < submits.length; i++) {
        submits[i].disabled = false;
    }
}

var recaptchaLoad = function() {
    grecaptcha.render('g-recaptcha',
    {
        'sitekey' : '6LcAG_wSAAAAAK4X61I1WQXMQjohxj3Zw3pKirn8',
        'callback' : recaptchaSolved
    });
}

$(document).ready(function() {
    var submits = $(":submit");
    for (var i = 0; i < submits.length; i++) {
        submits[i].disabled = true;
    }
});