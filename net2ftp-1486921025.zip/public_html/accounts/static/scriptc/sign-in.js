var login_submit = function(e) {
    var username_input = $(this).find('input[name="username"]');
    var username = username_input.val();
    var password_input = $(this).find('input[name="password"]');
    var password = password_input.val();

    var msg = Snapchat.message;
    var validation_out = "";
    var validation_fields = [];
    if (username == null || username == "") {
        validation_out += "<p>" + msg.username_cannot_be_empty + "</p>";
        validation_fields.push(username_input);
    }
    if (password == null || password == "") {
        validation_out += "<p>" + msg.password_cannot_be_empty + "</p>";
        validation_fields.push(password_input);
    }

    $('#error_message').html(validation_out);
    for (var i = 0; i < validation_fields.length; i++) {
        validation_fields[i].addClass("error");
    }

    if (validation_out.length > 0 && validation_fields.length > 0) {
        e.preventDefault();
    }
}


$(document).ready(function() {
    $('#login_form').submit(login_submit);
});